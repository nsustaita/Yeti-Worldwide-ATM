# Start of Yeti ATM GUI Tkinter Code
import tkinter as tk  # python 3

# Set up to form frame on each page
from tkinter

class SampleApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (LoginPage, ATMMenu, PageTwo):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            # put all of the pages in the same location;
            # the one on the top of the stacking order
            # will be the one that is visible.
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("LoginPage")

    # Adds frame on the container frame
    def show_frame(self, page_name):
        '''Show a frame for the given page name'''
        frame = self.frames[page_name]
        frame.tkraise()


class LoginPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg='#476b6b')
        self.controller = controller

        self.controller.title('Yeti World Wide ATM')
        self.controller.state('zoomed')
        self.controller.iconphoto(False,
                                  tk.PhotoImage(file='C:/Users/nates/Desktop/Yeti World Wide ATM/yeti.png'))
        headingLabel1 = tk.Label(self,
                                 text='Yeti World Wide ATM',
                                 font=('antarctica', 48, 'bold'),
                                 foreground='white',
                                 background='#476b6b')
        headingLabel1.pack(pady=20)

        space_label = tk.Label(self, height=4, bg='#476b6b')
        space_label.pack()

        Pass_label = tk.Label(self,
                              text='Enter Your Secret Password',
                              font=('antarctica', 15),
                              bg='#476b6b',
                              fg='white')
        Pass_label.pack(pady=10)

        my_pass = tk.StringVar()
        Pass_entry_box = tk.Entry(self,
                                  textvariable=my_pass,
                                  font=('antarctica', 12),
                                  width=25)
        Pass_entry_box.focus_set()
        Pass_entry_box.pack(ipady=9)

        def hide_pass(_):
            Pass_entry_box.configure(fg='black', show='$')

        Pass_entry_box.bind('<FocusIn>', hide_pass)

        def check_password():
            if my_pass.get() == 'RiverWalk12':
                controller.show_frame('ATMMenu')

            else:
                wrong_pass_label['text'] = 'Wrong Password, Please try again!'

        Enter_button = tk.Button(self,
                                 text='Enter',
                                 command=check_password,
                                 relief='raised',
                                 borderwidth=3,
                                 width=27,
                                 height=3)

        Enter_button.pack(pady=5)

        wrong_pass_label = tk.Label(self,
                                    text='',
                                    font=('antarctica', 12),
                                    fg='white',
                                    bg='#3d5c5c',
                                    anchor='n')
        wrong_pass_label.pack(fill='both', expand=True)


class ATMMenu(tk.Frame):
    # Page 2 of Yeti World Wide ATM

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg='grey')
        self.controller = controller


class PageTwo(tk.Frame):
    # Page 3 of Yeti World Wide ATM

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg='grey')
        self.controller = controller


if __name__ == "__main__":
    app = SampleApp()
    app.mainloop()